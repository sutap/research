
package com.checkreader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CheckReaderApplication {
    public static void main(String[] args) {
        SpringApplication.run(CheckReaderApplication.class, args);
    }
}
