
package com.checkreader;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.*;

@RestController
@CrossOrigin
public class CheckAnalyzerController {

    @PostMapping(value = "/analyze-check", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, String> analyzeCheck(@RequestParam("file") MultipartFile file) throws IOException {
        File tempFile = File.createTempFile("check", ".jpg");
        file.transferTo(tempFile);

        Tesseract tesseract = new Tesseract();
        tesseract.setDatapath("/usr/share/tesseract-ocr/4.00/tessdata/"); // adjust if needed
        tesseract.setLanguage("eng");

        String ocrResult;
        try {
            ocrResult = tesseract.doOCR(tempFile);
        } catch (TesseractException e) {
            throw new RuntimeException("OCR failed", e);
        }

        Map<String, String> result = new HashMap<>();
        result.put("rawText", ocrResult);
        result.put("routingNumber", extractPattern(ocrResult, "\b\d{9}\b"));
        result.put("accountNumber", extractPattern(ocrResult, "\b\d{6,12}\b"));
        result.put("checkNumber", extractPattern(ocrResult, "\b\d{3,6}\b"));
        result.put("amount", extractPattern(ocrResult, "\$?\d{1,5}\.\d{2}"));

        return result;
    }

    private String extractPattern(String text, String pattern) {
        Matcher matcher = Pattern.compile(pattern).matcher(text);
        return matcher.find() ? matcher.group() : "Not found";
    }
}
