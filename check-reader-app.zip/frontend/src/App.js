
import React, { useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    setFile(e.target.files[0]);
    setPreview(URL.createObjectURL(e.target.files[0]));
  };

  const handleSubmit = async () => {
    const formData = new FormData();
    formData.append("file", file);

    const response = await axios.post("http://localhost:8080/analyze-check", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    setResult(response.data);
  };

  return (
    <div className="app">
      <h1>🧾 Check Reader</h1>
      <input type="file" onChange={handleChange} />
      <button onClick={handleSubmit}>Upload and Analyze</button>
      {preview && <img src={preview} alt="Check Preview" width="400" />}
      {result && (
        <table>
          <tbody>
            {Object.entries(result).map(([key, value]) => (
              <tr key={key}>
                <td><strong>{key}</strong></td>
                <td>{value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default App;
